/* source: hostan.h */
/* Copyright Gerhard Rieger 2006 */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __hostan_h_included
#define __hostan_h_included 1

extern int hostan(FILE *outfile);

#endif /* !defined(__hostan_h_included) */
