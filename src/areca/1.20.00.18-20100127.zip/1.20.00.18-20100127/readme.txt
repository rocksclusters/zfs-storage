
     ARECA SATA/SAS RAID CONTROLLER (ARC11XX/ARC12XX/ARC13XX/ARC16XX)
       
            Solaris 10 2006 1/06, 06/06 .... i86pc 32-64 (DVD)
            Solaris 11 2007 (Express) .... i86pc 32-64 (DVD)
            Solaris OpenSolaris
     ===================  Driver User's Guide  =======================

	Solaris SCSI driver technical support
	mail address: erich@areca.com.tw
	         Tel: 886-2-8797-4060 Ext.203
	         Fax: 886-2-8797-5970
	    Web site: www.areca.com.tw
     =================================================================

**********************************************************************
** 1. Contents                                                      **
**********************************************************************

readme.txt     - (This file)The readme file for ARC11XX/ARC12XX Solaris scsi raid driver
	
SUNWarcmsr.ZIP - Ziped solaris software package style of ARECA RAID driver
                 for user attempt to add ARECA RAID driver on Existing Solaris System
	                        
ARCMSR.DD.ZIP  - Ziped supplemental dirver disk (DU) image of 1.44M floppy diskette
                 for user attempt to install New Solaris System at ARECA RAID VOLUME
                            
********************************************************************
** 2. Install New Solaris System at ARECA RAID VOLUME             **
********************************************************************
A. Before Installation:

 - Under DOS/Windows environment

	 a. Unzip "ARCMSR.DD.ZIP"
	    X:\PATH\pkunzip.exe ARCMSR.DD.ZIP =>> arcmsr.dd
	 b. Dump it into a floppy disk.
	    X:\PATH\rawrite.exe arcmsr.dd A:

	 Tips: You can get any rawrite.exe from world wide web search
	 
 - Under Solaris or other Unix environment
     
         a. Unzip "ARCMSR.DD.ZIP"	              
           % unzip -L ARCMSR.DD.ZIP
         b. Dump it into a floppy disk  
            Put a floppy diskette into your floppy diskette drive   
            Generic unix:	   
                        % dd if=arcmsr.dd of=/dev/fd0
            Solaris:
                        % volcheck 
                        % fdformat -d -U
                        % dd if=arcmsr.dd of=/vol/dev/aliases/floppy0 bs=36k
                        % eject floppy
                        
            Solaris:(USB)         
            				    % fdformat -d -U
                        % dd if=arcmsr.dd of=/vol/dev/aliases/noname bs=36k	   
                        
  P.S:
    If you do not have floppy drive on your system,
    you need to copy "DU" folder from floppy diskette image into your media,
    and let your installation program attach it.
    Solaris Express "installation program" had this function for you.                        

B. start Solaris installation
******************************************
**   For Solaris 11 (Express)
******************************************

Step 1.  Boot your system from installation DVD.
         When the following menu appear:

               1. Solaris Interactive (default)
	       			 2. Custom JumpStart.
               3. Solaris Interactive Text (Desktop session)
               4. Solaris Interactive Text (Console session)
               5. Apply driver updates
               6. Single user shell
         Enter the number of your choice.
         Selected: 5

         Please select "5" for loading your raid adapter driver.
     
         After reboot, you need to make sure that your DVD 
         and ARECA supplemental dirver diskette are no longer inside.
        
Step 3.  Reboot your machine.

******************************************
**   For Solaris 10 2006 1/16, 06/06, ....
******************************************

Step 1.  Boot your system from installation DVD.
         When the following menu appear:

               1. Solaris Interactive (default)
	           2. Custom JumpStart.
               3. Solaris Interactive Text (Desktop session)
               4. Solaris Interactive Text (Console session)
               5. Apply driver updates
               6. Single user shell
         Enter the number of your choice.
         Selected: 5

         Please select "5" for loading your raid adapter driver.
     
         After reboot, you need to make sure that your DVD 
         and ARECA supplemental dirver diskette are no longer inside.
        
Step 3.  Reboot your machine.

**********************************************
**   Procedure For Solaris 10 2005 03/05 Rev.A
**********************************************

Step 1.  When the Solaris "Running Device Configuration Assistant" screen appears, 
         Push ESC button for disable autoboot procedure 
         and 
         than Press "ESC-4" for add driver
    
         The message "Bus Enumeration" ... appears... 

Step 2.  Press "Enter" for continue.

         The message "Install Supplemental Dirvers" ... appears...
    
Step 3.  If you booted from the Solaris Device Configuration Assistant Diskette,
         remove it from the diskette drive and insert ARECA supplemental dirver disk (arcmsrDU.img).

         Then Press "Esc-2" for continue
    
Step 4.  When "Select Solaris Operation Version" ... appears...

         Select the appropriate Solaris operating system, 
         
         Then Press "Esc-2" for continue.

         The Loading Driver Update Software screen appears, along with a progress
         bar that shows the percentage of drivers that have been extracted from the diskette. 
         ARECA real mode drivers were read into memory 
         and survive long enough for the system to successfully boot to its installation program. 
    
Step 5.  When "Continue Supplemental Dirver Installation" ... appears...
    
         Then Press "Esc-4" for Done

Step 6.  When "Identifed Device Drivers" ... appears...

         You should see "arcmsr - Device Driver"
    
         Then Press "Esc-2" for continue

Step 7.  When "Solaris Device Configuration Assistant" ... appear...
         You can Repeat Step 3 through Step 7.
         Until all the Solaris Driver ITU diskettes you want are installed.

Step 8.  When "Boot Solaris" ... appear...
         
         Please Select Your BOOT CDROM for solaris Boot
         
         Then Press "Esc-2" for continue normal Solaris installation
         
         After reboot just make sure the DVD and ARECA supplemental dirver diskette are no longer inside.
        
Step 9.  Reboot your machine.

         When the Solaris operating environment is finished booting and running, 
         the new devices whose drivers that you installed are available for use.

**********************************************************************
** 2. Add ARECA RAID Driver on Existing Solaris System              **
**********************************************************************

A.Install ARECA RAID Driver with SUNWarcmsr.zip:

	%cd /var/spool/pkg/
	%cp ../../SUNWarcmsr.zip ./
	%unzip SUNWarcmsr.zip 
	# you will get folder "SUNWarcmsr" at /var/spool/pkg/
	%cd /
	%pkgadd SUNWarcmsr
	...
	..
	.
	# now you have areca raid driver install successfully

B.Install ARECA RAID Driver with ARCMSR.DD.ZIP:

        1. Unzip "ARCMSR.DD.ZIP"	              
           % unzip -L ARCMSR.DD.ZIP	   
        2. Dump it into a floppy disk.          
           % dd if=arcmsr.dd of=/dev/fd0
        3. Mount this floppy diskette
           % volcheck
        4. SUNWarcmsr package driver add
           % /floppy/areca/DU/sol_210/i86pc/Tools/install.sh
             ...
             ..
             .
        # now you have areca raid driver install successfully
        
P.S     3. Mount this floppy diskette (USB)
           % mount -F pcfs /vol/dsk/areca /mnt
           % /mnt/DU/sol_210/i86pc/Tools/install.sh        
        
        